Soy Cristina, estudiante de periodismo y humanidades, del grupo 61.
